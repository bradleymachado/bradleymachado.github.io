# cs_continue_v1.1 — This section is intended to keep a Code Strategy session working until the plan is done.
# Stop hook: reads .code-strategy/state.json in the working directory. While phase == "running" it asks
# Claude Code to continue instead of ending the turn; "hold" (hard stop) and "done" (closeout) allow the stop.
# Output shape per code.claude.com/docs/en/hooks (2026-10): {"decision": "block", "reason": ...}; "ok" kept for older builds.
# Claude Code caps consecutive stop-hook blocks (default 8; env CLAUDE_CODE_STOP_HOOK_BLOCK_CAP) as a backstop.
import json, os, sys

STATE = os.path.join(os.getcwd(), ".code-strategy", "state.json")

def main():
    try:
        json.load(sys.stdin)  # hook payload; not needed beyond confirming valid input
    except Exception:
        pass
    phase = "done"
    try:
        with open(STATE, encoding="utf-8") as f:
            phase = json.load(f).get("phase", "done")
    except Exception:
        phase = "done"  # no state file -> not a Code Strategy run -> allow stop
    if phase == "running":
        print(json.dumps({
            "decision": "block", "ok": False,
            "reason": "Code Strategy state is 'running': continue with the next subtask in the plan register. "
                      "Set .code-strategy/state.json phase to 'hold' (hard stop) or 'done' (closeout) before ending the turn."
        }))
    else:
        print(json.dumps({"ok": True}))  # no decision key = allow stop
    return 0

if __name__ == "__main__":
    sys.exit(main())
