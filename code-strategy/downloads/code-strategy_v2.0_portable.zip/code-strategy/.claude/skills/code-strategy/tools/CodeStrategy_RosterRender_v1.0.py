#!/usr/bin/env python3
# CodeStrategy_RosterRender_v1.0 — This section is intended to regenerate a Code Strategy plan's roster chart:
# it reads the plan's "## Roster" table, rewrites the Mermaid block between <!-- roster:mermaid --> markers
# in the same file, and writes <Plan stem with Plan→Roster>_v<M>.<m>.html beside it (one card per unit).
# Usage (Git Bash or PowerShell):  python CodeStrategy_RosterRender_v1.0.py "<path to plan .md>"
import html
import re
import sys
from pathlib import Path

COLS = ["id", "title", "does", "agent", "reviewer", "reports", "status"]


def read_roster(text):
    m = re.search(r"^## Roster\s*$(.*?)(?=^## |\Z)", text, re.S | re.M)
    if not m:
        sys.exit("no '## Roster' section found")
    rows = []
    for line in m.group(1).splitlines():
        if not line.startswith("|") or set(line.strip()) <= set("|-: "):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if cells[0].lower() == "id":
            continue
        if len(cells) < 7:
            cells += [""] * (7 - len(cells))
        rows.append(dict(zip(COLS, cells[:7])))
    if not rows:
        sys.exit("roster table is empty")
    return rows


def level(uid):
    u = uid.upper()
    if u == "P":
        return "P"
    if re.match(r"M\d", u):
        return "M"
    if re.match(r"T\d+\.S", u) or re.match(r"S\d", u):
        return "S"
    if re.match(r"T\d", u):
        return "T"
    return "S"


def node_id(uid):
    return "n_" + re.sub(r"[^A-Za-z0-9]", "_", uid)


def mermaid(rows):
    out = ["```mermaid", "flowchart TD"]
    for r in rows:
        label = "<br/>".join([
            f"{r['id']} · {r['title']}",
            f"does: {r['does']}",
            f"agent: {r['agent']}",
            f"reviewer: {r['reviewer']}",
            f"reports to: {r['reports']} · {r['status']}",
        ]).replace('"', "'")
        out.append(f'  {node_id(r["id"])}["{label}"]')
    ids = {r["id"] for r in rows}
    for r in rows:
        if r["reports"] in ids:
            style = "-.->" if r["status"].upper().startswith("FAIL") else "-->"
            out.append(f"  {node_id(r['reports'])} {style} {node_id(r['id'])}")
    out.append("```")
    return "\n".join(out)


def write_mermaid(path, text, block):
    start, end = "<!-- roster:mermaid -->", "<!-- /roster:mermaid -->"
    if start in text and end in text:
        pre, rest = text.split(start, 1)
        _, post = rest.split(end, 1)
        text = f"{pre}{start}\n{block}\n{end}{post}"
    else:
        text = re.sub(r"(^## Roster\s*$.*?)(?=^## |\Z)",
                      lambda m: m.group(1).rstrip() + f"\n\n{start}\n{block}\n{end}\n\n", text, count=1, flags=re.S | re.M)
    path.write_text(text, encoding="utf-8")


CSS = """
:root{--ink:#1b2a3a;--ink2:#4a5b6c;--ink3:#8a98a6;--line:#d6dde4;--tint:#eef2f5;--bg:#fff}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--ink:#e6edf3;--ink2:#b4c0cc;--ink3:#7d8b99;--line:#2b3946;--tint:#16202a;--bg:#0f161d}}
:root[data-theme="dark"]{--ink:#e6edf3;--ink2:#b4c0cc;--ink3:#7d8b99;--line:#2b3946;--tint:#16202a;--bg:#0f161d}
body{margin:0;background:var(--bg);color:var(--ink);font:13px/1.45 Helvetica,Arial,sans-serif;padding:48px 16px}
main{max-width:1400px;margin:0 auto}
h1{font-weight:400;font-size:22px;letter-spacing:.02em;margin:0 0 4px}
.sub{color:var(--ink3);margin:0 0 40px}
h2{font-size:11px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--ink3);margin:32px 0 10px;border-top:1px solid var(--line);padding-top:12px}
.row{display:flex;flex-wrap:wrap;gap:12px}
.card{flex:1 1 220px;max-width:320px;border:1px solid var(--line);padding:12px 14px;color:var(--ink2)}
.card .id{color:var(--ink);font-weight:600;margin-bottom:6px}
.card .st{margin-top:6px;color:var(--ink3)}
.card.run{border-left:3px solid var(--ink)}
.card.pass{background:var(--tint);border-left:3px solid var(--ink)}
.card.hold{border-style:dashed}
.card.fail{border-style:dashed;color:var(--ink3)}
.key{margin-top:40px;color:var(--ink3);font-size:12px}
"""

LANES = [("P", "L0 · Program"), ("M", "L1 · Master task"), ("T", "L2 · Task"), ("S", "L3 · Subtask")]


def card(r):
    st = r["status"].upper()
    cls = "fail" if st.startswith("FAIL") else "pass" if st.startswith("PASS") else \
        "hold" if ("WAIT" in st or "HOLD" in st) else "run" if "RUN" in st else ""
    e = {k: html.escape(v) for k, v in r.items()}
    return (f'<div class="card {cls}"><div class="id">{e["id"]} · {e["title"]}</div>'
            f'<div>does: {e["does"]}</div><div>agent: {e["agent"]}</div><div>reviewer: {e["reviewer"]}</div>'
            f'<div>reports to: {e["reports"]}</div><div class="st">status: {e["status"]}</div></div>')


def page(rows, title, stem):
    body = ""
    for key, name in LANES:
        lane = [r for r in rows if level(r["id"]) == key]
        if lane:
            body += f'<section><h2>{name}</h2><div class="row">{"".join(card(r) for r in lane)}</div></section>'
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)} roster</title>'
            f'<style>{CSS}</style></head><body><main><h1>{html.escape(title)} · roster</h1>'
            f'<p class="sub">{html.escape(stem)} · regenerated from the plan\'s Roster table · each card: does, agent and tier, '
            f'reviewer and tier, reports to, status</p>{body}'
            f'<p class="key">solid left bar = running · tinted = PASS · dashed = waits or HOLD · dashed grey = FAIL, kept beside its retry</p>'
            f'</main></body></html>')


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__ or "usage: CodeStrategy_RosterRender_v1.0.py <plan.md>")
    plan = Path(sys.argv[1])
    text = plan.read_text(encoding="utf-8")
    rows = read_roster(text)
    write_mermaid(plan, text, mermaid(rows))
    stem = plan.stem.replace("_Plan_", "_Roster_") if "_Plan_" in plan.stem else plan.stem + "_Roster"
    out = plan.with_name(stem + ".html")
    title = re.sub(r"_Roster_v[\d.]+$", "", stem).replace("_", " ")
    out.write_text(page(rows, title, stem), encoding="utf-8")
    print(f"roster: {len(rows)} units → {plan.name} (mermaid), {out.name}")


if __name__ == "__main__":
    main()
