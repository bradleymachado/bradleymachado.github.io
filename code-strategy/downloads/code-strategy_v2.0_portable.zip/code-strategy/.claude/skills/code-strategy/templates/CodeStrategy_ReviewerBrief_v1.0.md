CodeStrategy_ReviewerBrief_v1.0 · 2026-10-15 · used by code-strategy skill v2.0 §6

# Reviewer brief (orchestrator → cs-gate-*)

Spawn the reviewer named in the register with this prompt. Substitute every bracket. Do not add the orchestrator's own opinion of the return.

```
GATE T<n>.S<m> <Short title>
Project: <project> — <course>. Review the return of subtask S<n>.<m> only. You are <cs-gate-lite|high|top>; the executor was <cs-exec-*>.

THE ASK (packet, verbatim):
<paste the packet that was given to the executor>

THE ANSWER (return, verbatim):
<paste the REPORT block the executor returned>
Logged files to open: <paths>

THE FIT (parent need):
Next unit: T<n>.S<m+1> <title> (or T<n+1> merge). Its section lists these inputs: <name → unit → format, one per line, copied from the plan>.

Checks, in order: 1 files exist at the logged paths · 2 every acceptance check PASS with its value, consistent with the files · 3 the return fits the parent need above.
Return exactly the ACCEPT or REJECT block from your agent definition. Nothing may follow.
```

Tier rule: `cs-gate-lite` reviews `cs-exec-lite` returns only; `cs-gate-high` reviews `cs-exec-medium`; `cs-gate-top` reviews `cs-exec-high` and `cs-exec-top`. A retry (`b`, `c`) moves the reviewer up with the executor.

On `REJECT`, the orchestrator records the `Cause` line on the roster card and in the log, then runs the fail ladder (§6).
