CodeStrategy_Packet_v1.0 · 2026-10-15 · used by code-strategy skill v2.0 §5 and §10

# Context packet (orchestrator → executor)

A packet is everything the executor may see. It is cut from the ledger by the orchestrator. The seven parts, in order:

| # | Part | Source in the ledger | Rule |
|---|---|---|---|
| 1 | Identity | register row | `T<n>.S<m> <title>`, time budget, executor file, correction letter if any |
| 2 | Fixed inputs · Tooling rules · Folders | plan tables | copied whole, never summarized |
| 3 | Plan section | `### S<n>.<m>` only | steps, outputs, checks with check values |
| 4 | Upstream values | prior REPORT blocks | substituted into the inputs line, with units |
| 5 | Acceptance checks | plan section | each with its check value |
| 6 | Return contract | SKILL §9 | the REPORT block, then `LOG: appended` |
| 7 | Exclusions | — | named explicitly: other sections, other tasks' log entries, source PDFs, orchestrator reasoning |

Prompt skeleton: SKILL v2.0 §10. A packet that needs a value the plan does not hold is a plan fault: revise the plan (minor bump) before spawning, never ask the executor to find it.

Size guide: a packet should fit in one screen of the terminal plus the plan section. If it does not, the subtask is too large; split it in the plan.
