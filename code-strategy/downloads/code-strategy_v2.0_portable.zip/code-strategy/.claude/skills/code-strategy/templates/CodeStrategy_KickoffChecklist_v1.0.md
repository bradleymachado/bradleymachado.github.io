CodeStrategy_KickoffChecklist_v1.0 · 2026-10-15 · used by code-strategy skill v2.0 §Kickoff

# Kickoff question checklist

Rule B1: every clarifying question the strategy needs is asked and answered before any plan is written or any run starts. One question per turn. There is no cap on the number of questions. No plan, roster, or run starts while a question is open. The first product after kickoff is the plan plus the roster chart.

## Procedure

1. Read `<Project>_Kickoff_v*.md` first (template `Project_Kickoff_TEMPLATE_v2.0.md`). No file → copy the template into the project folder root as `<Project>_Kickoff_v1.0.md`.
2. Walk the table below in order. Ask only for rows that are blank or ambiguous (two readings, a placeholder, or a value that conflicts with the brief). A filled, unambiguous row is never asked.
3. Ask one question per turn, using the question text, and end the turn with `STOP — report <value> before I continue.` Wait for the answer. Do not batch questions.
4. If the user declines or says "default", record the default from the table and log it under `Decisions without input` with its revert cost.
5. After the last answer, write all answers and defaults into the kickoff file (minor version bump, old file to `_superseded`). Only then start Task 0 / Strategy.
6. A question that surfaces during Strategy goes through the same loop before the plan is written.

## Questions

| # | Kickoff row | Question (one line answer) | Why the plan needs it | Default if declined |
|---|---|---|---|---|
| 1 | Project name / course | What are the project name and course code? | File names, session name, log headers | Project folder name |
| 2 | Brief (path) | Which file is the brief? | Task 0 intake and fixed inputs | Only file named `*brief*` in the folder; none → H1 |
| 3 | Project folder | Which folder is the project root? | Folder table, outputs, `.code-strategy/` | Folder the skill was launched in |
| 4 | Deliverables | Which deliverables must be submitted? | Subtask list and acceptance checks | Every deliverable the brief names |
| 5 | Toolchain — modeling | Which modeling tool per deliverable? | S1 environment check, step instructions | Tool used in existing working files, else Rhino 8 + GH1 |
| 6 | Toolchain — analysis | Which analysis tool per deliverable? | S1 check, analysis subtasks | Python (pandas) |
| 7 | Toolchain — layout | Which layout tool per deliverable? | Layout subtasks, export format | Format the brief requires, else PowerPoint |
| 8 | Success criterion | Compliance with margin, maximum measured performance, design narrative, or a stated balance? | Check values and optimum vs design case | Compliance with margin |
| 9 | Option tables / limits are | Are the brief's option tables and limits a floor, a boundary, or examples? | Design space for subtasks | Boundary (stay inside) |
| 10 | Deadline | What is the deadline (date, time, timezone)? | Schedule anchor, upload target 1 h before | Date in brief, 09:00 local; none → H2 |
| 11 | Submission method and format | How and in what format is it submitted? | Closeout export and naming | Method and format in brief, else PDF upload |
| 12 | Hours available | How many hours of your time are available before the deadline? | User column, Stop class load | 0 h beyond Stop-class actions |
| 13 | Sources present / missing | Are any sources the brief names missing from the folder? | Task 0 `MISSING` rows | Log each as `MISSING`, continue |
| 14 | Master tasks | Does this project need more than one master task (rare, e.g. a marketing follow-on)? | Master-task procedure, extra kickoff files | One master task (M1) |
| 15 | Executor preferences | Any model/effort defaults for this project's executors? | Plan assigns each unit's executor with a reason | Skill menu defaults; plan assigns per unit |
| 16 | Extra review stops | Any review stops wanted beyond the planned gates? | Stop rows in the register | None beyond planned gates |
| 17 | Portfolio capture | Do you want portfolio image capture? | Capture steps and image folder | Yes, process images only |
| 18 | Standing decisions | Any standing decisions to apply throughout? | Tooling rules, defaults | None |

Defaults are conservative: each one either follows the brief or keeps scope narrow, so a later answer adds work rather than undoing it.
