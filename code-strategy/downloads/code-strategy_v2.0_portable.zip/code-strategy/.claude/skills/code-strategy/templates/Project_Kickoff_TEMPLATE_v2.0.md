# <Project> — Kickoff

Rename to `<Project>_Kickoff_v1.0.md` and place in the project folder root. Rows follow `CodeStrategy_KickoffChecklist_v1.0` in the same order. A filled, unambiguous row is never asked; each blank or ambiguous row is asked one question per turn before any plan is written.

| # | Field | Value |
|---|---|---|
| 1 | Project name / course | |
| 2 | Brief (path) | |
| 3 | Project folder | |
| 4 | Deliverables | |
| 5 | Toolchain — modeling | |
| 6 | Toolchain — analysis | |
| 7 | Toolchain — layout | |
| 8 | Success criterion | |
| 9 | Option tables / limits are | |
| 10 | Deadline (date, time, timezone) | |
| 11 | Submission method and format | |
| 12 | Hours of my time available before deadline | |
| 13 | Sources present / missing | |
| 14 | Master tasks (one, or more) | |
| 15 | Executor preferences (model / effort defaults) | |
| 16 | Extra review stops | |
| 17 | Portfolio capture (yes / no) | |
| 18 | Standing decisions I want applied | |
