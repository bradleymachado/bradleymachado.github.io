CodeStrategy_RosterCard_v1.0 · 2026-10-15 · used by code-strategy skill v2.0 §4.7–4.8

# Roster table and card

The plan's `## Roster` table is the source of truth. One row per unit (P, M<n>, T<n>, S<n>.<m>, and every retry `b`/`c`). The renderer (`tools/CodeStrategy_RosterRender_v1.0.py`) turns it into the Mermaid block and the HTML page.

```
## Roster

| Id | Title | Does | Agent · tier | Reviewer · tier | Reports to | Status |
|---|---|---|---|---|---|---|
| P | <project> | fixed inputs, hand-offs | orchestrator · Fable high | user at closeout | user | running |
| M1 | <deliverable> | T1…Tn plan, check values | this session · Fable high | cs-gate-top · Fable high | P | running |
| T1 | Environment | MCP list, versions | orchestrator role | cs-gate-high · Opus high | M1 | PASS 3/3 |
| T1.S1 | <title> | <does> | cs-exec-medium · Opus med | cs-gate-high · Opus high | T1 | PASS 3/3 |
| T2.S2 | <title> | <does> | cs-exec-high · Opus high | cs-gate-top · Fable high | T2 | FAIL 2/3 · check 2 no value |
| T2.S2b | <title> (retry) | <does> | cs-exec-top · Fable high | cs-gate-top · Fable high | T2 | PASS 3/3 |
```

Status vocabulary: `queued` · `running` · `PASS n/n` · `FAIL n/n · <reviewer cause>` · `waits on <unit|Brad (H<n>)>` · `HOLD (H<n>)`.

Card (one per row, five lines after the title): does · agent and tier · reviewer and tier · reports to · status. A FAIL row stays in the table and on the chart beside its retry; its Status cell carries the reviewer's `Cause` so the question "why did both miss it" is answered from the card.

Mermaid block, written by the renderer between the markers below (hand edits are overwritten):

```
<!-- roster:mermaid -->
<!-- /roster:mermaid -->
```
