---
name: code-strategy
description: Use when the user starts or resumes a project in Claude Code and wants it run end-to-end with minimal input — every clarifying question asked up front, a strategy plan plus a roster chart as the first product, subtasks run by subagents sized to the work, every return checked by a separate review gate, living plan and progress log, a REPORT block per subtask, automatic circle-back. Stops only for physical actions, undefined objectives, destructive steps, or missing tools.
---

# Code Strategy — autonomous strategy plan for Claude Code (skill v2.0)

Purpose: one strategy conversation builds the plan for a project, assigns agents to action the plan, ensures the plan was followed, and returns a completed and vetted project.

Execution model: one Claude Code session in the project folder is the **orchestrator**. It asks every question first, writes the plan and the roster chart, then cuts a **context packet** for each subtask, spawns a **fresh executor subagent** per subtask, passes each return through a **review gate** staffed by a separate agent one tier above the executor, merges accepted returns upward, and moves on without waiting for the user unless a hard stop is met. The user reads the roster, the REPORT blocks (terminal) and the progress log (record). Sibling of `strategy-plan` (chat version, not yet updated to this model).

## 1. Operating rules — read first

1. **Questions first, then autonomy.** Every clarifying question is asked and answered before any plan is written or any run starts (§2). After that, proceed under stated defaults. Every default, assumption, or ambiguity resolution is written to the progress log under `Decisions without input`, each with its revert cost (`revert: rerun S4, 20 min`). Never ask the user mid-run about anything a default covers.
2. **Hard stops** — the only reasons to end a turn before closeout:
   - **H1 Physical**: an action only the user can do — launch or attach a desktop application, license activation, sign-in, hardware, a source file or folder the user must supply.
   - **H2 Objective undefined**: two readings of the brief produce materially different deliverables and no conservative reading (one that satisfies both) exists.
   - **H3 Destructive**: overwriting or deleting a file this run did not create; committing, pushing, sending, or publishing anything outside the project folder; changing anything under `~/.claude/`.
   - **H4 Blocked resource**: a required MCP server, plugin, library, or application is absent after the S1 remediation attempt.
   At a hard stop: log `BLOCKED — needs user: <what>`, set state `hold`, print the position line (`T2.S3, Step 2 of 4 — <context>`), ask exactly one question, append `STOP — report <value> before I continue.`, end the turn. On the user's reply: restate position in one line, set state `running`, resume with the next step only.
3. **Permissions.** Never `--dangerously-skip-permissions` or `bypassPermissions`. Run in `acceptEdits` (or `auto`) with the allow-list from the install bundle. A permission prompt mid-run is not a hard stop.
4. **Context packets.** No agent reads the whole plan. The orchestrator holds the register, the roster and the log tail. Each executor receives one packet (§5) and nothing else; each reviewer receives the packet, the return, and the parent's need (§6). The project folder is the **ledger** (file index, plans, roster, log, decisions, state, images): packets are cut from it, returns are appended to it, no level reads all of it.
5. **Report every subtask** (format §9) in the terminal and in the log. One line per step, no narrative.
6. **Gate, do not trust.** No return merges upward until a separate reviewer has issued `ACCEPT`. The orchestrator never accepts its own packet's return by inspection alone.
7. **State file.** `.code-strategy/state.json` holds `{"phase": "running" | "hold" | "done", "position": "<Task>.<Subtask>", "updated": "<ISO time>"}`, updated at every transition. The optional Stop hook reads it to keep the session working while `running`.

## 2. Kickoff — `/code-strategy <brief path | project folder | resume>`

1. Read, if present: `<Course>_FileIndex_v*.md`, `<Project>_Kickoff_v*.md`, the latest plan, the roster, the progress log, `.code-strategy/state.json`. Determine position: no index → Task 0; index but no plan → Strategy; plan with open subtasks → resume at the first subtask not PASS; all PASS → circle-back; `state.phase == hold` → repeat the pending STOP question and wait.
2. Name the session `<Project> — Code Strategy` (`/rename`, or `--name` at launch).
3. **Questions.** Walk `CodeStrategy_KickoffChecklist_v1.0.md` (bundle, `templates/`) against the kickoff file. Every row that is blank or ambiguous is asked, **one question per turn**, each turn ending `STOP — report <value> before I continue.` There is no cap on the number of questions. A question that surfaces during Task 0 or Strategy goes through the same loop before the plan is written. No plan, roster, or run starts while a question is open. After the last answer, write all answers into the kickoff file (minor bump).
4. Then run without stopping: Task 0 → Strategy (plan + roster, one planned stop) → execution → circle-back → closeout.

## 3. Task 0 — Source intake (subagents, parallel)

**0.0 Intake.** List every candidate source in the project folder. For each, spawn `cs-intake` (up to 5 in parallel) to write `<Course>_<Doc>_<Type>_v1.0.md` beside the original: source line, page markers `<!-- p. N -->`, tables as Markdown, figures in brackets, exact wording for requirements, dates, numbers, constants. Copyrighted readings become study notes. A source the brief names but the folder lacks → `MISSING — <name>`, continue; only a missing brief is H1.

**0.1 Review.** For each converted document spawn `cs-review` to return a discrepancy list (`unambiguous` / `ambiguous`). Apply every unambiguous correction (minor bump). For each ambiguous item take the conservative reading and log it under `Decisions without input`; H2 only when no conservative reading exists. Deferred questions are consolidated into the closeout block.

**Index and log.** Write or update `<Course>_FileIndex_v1.0.md` (one row per source → Markdown path → type), first paragraph stating the read-Markdown-only rule. Print `REPORT 0.0/0.1`.

## 4. Strategy (orchestrator, in-session) — first product: plan + roster

1. Read the file index, the Markdown brief, rubric, template and kickoff file. Do not open source PDFs.
2. **Fixed inputs**: constraints, dimensions, code values, deadline, submission format. Pre-compute every check value. When the deliverable is scored on a metric, state the unconstrained optimum beside the design case.
3. **Levels.** Program (P) → master task (M1; M2+ only if the kickoff says so, §11) → tasks (T1…Tn) → subtasks (S<n>.<m>). **T1 = environment verification**: `claude mcp list`, application versions and plugins per the toolchain, Python and libraries, Git Bash, pandoc if a PDF is required; missing MCP server → `claude mcp add-from-claude-desktop`, re-list, then H4. Every subtask is fixed in the plan; the orchestrator plays the task role (cuts packets, merges returns). Each subtask record: id, short title, full name, estimated minutes, `Depends on`, inputs, ≤ 5 numbered steps with explicit UI or file instructions, required output files with paths, acceptance checks with check values, **executor and reason**, **reviewer**, `Stop class` (none / H1 / H3).
4. **Executor assignment.** The skill ships a menu (§8); the plan assigns. Level never sets the model: each unit gets the executor its work and the tightness of its packet justify, and the register records the reason. Defaults a plan may override with a stated reason: Opus medium for build-from-spec, Opus high for judgment or MCP-driven modeling, Fable high for optimization and code that must run first time; Sonnet medium where the packet carries every value and the step is mechanical. The reviewer is one tier above the executor (§6).
5. **Schedule**: sum the minutes, add 20% buffer, anchor to the deadline with the upload target at least one hour before it. Columns `Wall` and `User`.
6. **Tooling audit** and **folder structure** as in v1.0: reuse any structure already in the folder; otherwise two-digit-prefixed folders plus `.code-strategy/`. Flag deprecated tools and name the current alternative.
7. Write `<Course>_<Project>_Plan_v1.0.md`. Sections, in order: `## Status`, `## Decisions` (kickoff answers), `## Fixed inputs`, `## Tooling rules`, `## Folders`, `## Levels and gates`, `## Schedule`, `## Subtask register`, `## Roster` (table, one row per unit: id, title, does, agent · tier, reviewer · tier, reports to, status), `<!-- roster:mermaid -->` block, then one `### S<n>.<m> — <name>` section per subtask.
8. **Roster chart.** Run `tools/CodeStrategy_RosterRender_v1.0.py <plan path>` (bundle). It rewrites the Mermaid block from the `## Roster` table and writes `<Course>_<Project>_Roster_v<M>.<m>.html` beside the plan. Mermaid is the machine source; the HTML is the user's visual. Both are regenerated at every plan revision, every status change and every correction run. Failed runs stay on the roster beside their retry, so a miss can be traced to its packet and reviewer brief.
9. Create `<Course>_<Project>_ProgressLog_v1.0.md` with a Planning entry (kickoff answers, folder table, every default taken). Add every new Markdown file to the file index. Set `state.json` to `hold`, position `Plan`.
10. Print `REPORT Plan written` and `STOP — report roster approval before I continue.` This is the one planned stop before closeout. On approval set `running` and start T1.S1.

## 5. Packets and returns

**Packet** (handed down, cut from the ledger by the orchestrator, nothing more):
1. Identity: `T<n>.S<m> <title>`, time budget, executor tier.
2. Fixed inputs, Tooling rules, Folder table.
3. The plan section `### S<n>.<m>` only: steps, outputs, checks with check values.
4. Upstream measured values, substituted, with units.
5. Return contract: the REPORT block (§9).
6. Exclusions: other sections, other tasks' log entries, source PDFs, the orchestrator's reasoning.

**Return** (handed up): the REPORT block with PASS/FAIL per check and its value, files at the logged paths, measured values the next unit substitutes, decisions without input with revert cost, deviations, image names, `BLOCKED: H<n>` if any. The executor appends it to the log and ends with `LOG: appended`.

**Parent need** (given to the reviewer): the inputs the next unit's section lists — names, units, format.

## 6. Review gates

Every return passes a gate before it merges. The gate is a separate read-only agent (`cs-gate-*`, §8), never the producer, staffed one tier above the executor: Sonnet work → `cs-gate-lite`; Opus-medium work → `cs-gate-high`; Opus-high and Fable work → `cs-gate-top`. A Fable return is reviewed by a second Fable agent with the reviewer brief; a second `REJECT` at that level escalates to the user (H2).

Reviewer inputs: the packet, the return, the parent need. Three checks, in order:
1. Files exist at the logged paths.
2. Every acceptance check is PASS with its value.
3. Fits the parent: names, units and format match what the next unit's section needs.

Verdict: `ACCEPT` → orchestrator merges, Status PASS, roster updated. `REJECT: <check> — <reason>` → fail ladder:
- First FAIL → retry as `S<n>.<m>b` on the next executor tier (medium → high → top), reusing outputs that passed; reviewer moves up with it.
- Second FAIL → plan fault: revise the subtask's steps or check values (plan minor bump), rerun as `S<n>.<m>c` on the same tier.
- Third FAIL → hard stop (H2 or H4) with the three failure summaries.
- Downstream subtasks that consumed a failed value rerun with the same letter.
A reviewer disagreement with the plan is a plan revision, never a silent override.

## 7. Execution loop

For each subtask in register order (subtasks whose `Depends on` are all PASS may run in parallel, maximum 3):
1. Cut the packet (§10 template).
2. Spawn the executor named in the register. Foreground when the result gates the next subtask; background otherwise.
3. On return, spawn the reviewer named in the register with packet + return + parent need.
4. On `ACCEPT`: update `## Status` and `## Roster`, regenerate the roster, append the log entry if the executor did not, print the REPORT block, update `state.json`. On `REJECT`: fail ladder (§6), FAIL card kept on the roster beside its retry.
5. Next subtask.

Inside an executor steps run continuously. Every code file starts with `# <Name>_v1.0 — This section is intended to <process>.` Working documents are saved to the working-files folder with an incremented version before return. Desktop applications are attached via MCP, never launched; an application not open → `BLOCKED: H1 <app> not running`.

## 8. Executor and gate menu

Agent files in `~/.claude/agents/`. Model and effort are fixed in each file; the plan chooses which file each unit gets and records why.

| Agent | Model / effort | Typical use (plan decides) |
|---|---|---|
| `cs-exec-lite` | Sonnet, medium | Mechanical step, every value in the packet, check value present |
| `cs-exec-medium` | Opus, medium | Building from a spec: workbooks, sheets, GH graphs with known components, summaries, index rows |
| `cs-exec-high` | Opus, high | Design moves, written argument, MCP-driven modeling, any Stop-class subtask |
| `cs-exec-top` | Fable, high | Optimization, generative work without check values, code that must run first time |
| `cs-intake` | Opus, medium | Source → Markdown twin (Task 0) |
| `cs-review` | Opus, high | Markdown ↔ original discrepancy check (Task 0) |
| `cs-gate-lite` | Opus, medium | Gate for Sonnet returns only |
| `cs-gate-high` | Opus, high | Gate for Opus-medium returns |
| `cs-gate-top` | Fable, high | Gate for Opus-high and Fable returns |

The register carries `Executor`, `Reason`, `Reviewer`; the REPORT block states the executor actually used and the verdict.

## 9. REPORT block (after every subtask; terminal and log)

```
REPORT T2.S3 — Baseline Model — PASS 3/3 — 28 min wall / 0 min user — cs-exec-high — gate cs-gate-top ACCEPT
Steps: 1 <what was done> · 2 <…> · 3 <…>
Values: <measured values with units>
Files: <paths>   Images: <names>
Decisions without input: <default taken → revert cost> | none
Deviations: <…> | none
Next: T2.S4 Alternate Model — starting.
```

One line per step; values with units; `Next:` names the run and states `starting`, `parallel with …`, `HOLD (H1: …)`, or `closeout`. The identical block is the subtask's log entry.

## 10. Packet prompt template (executor)

```
T<n>.S<m> <Short title>
Project: <project> — <course>. Execute subtask S<n>.<m> only: <full name>.
Read, from <plan path>, ONLY the Fixed inputs, Tooling rules, and Folders tables and the section '### S<n>.<m>' — not the whole file — then the Task <n> entries in <log path>. Do not re-plan; follow the steps as written. Source material: only the Markdown files in <file index path>; open a source PDF only if the Markdown lacks the content, and log it.
Inputs: <inputs, measured values from prior subtasks substituted, with units>.
Time budget: <min> min wall. Required outputs: <files with folder paths>.
Acceptance checks: <checks with check values>.
Tooling rules: <toolchain, versions, plugin constraints>; the user's stated office formats. Attach to open desktop applications via MCP; never launch one. If a required application or MCP server is unavailable, return 'BLOCKED: H1 <detail>' or 'BLOCKED: H4 <detail>' immediately.
Decisions: take the conservative default for anything the plan leaves open; record each under 'Decisions without input' with its revert cost. Never ask a question.
Code: every code file starts with a comment block naming it '<Name>_v1.0' and stating 'This section is intended to <process>'.
Portfolio capture: export to <process-images folder> named <Project>_S<n>.<m>_<Desc>_v1.0.png — one environment image and one clean output image minimum. If only a screen capture would work, log 'IMAGE PENDING — user: screen capture <what>' and continue.
Save open working documents to <working-files folder> with an incremented version before returning.
Excluded: every other plan section, other tasks' log entries, source PDFs.
Return, as your final message, exactly the REPORT block (plan §REPORT) with every field filled, then 'LOG: appended' after appending the same block to the progress log. Nothing may follow.
```

Correction runs add after `Execute subtask`: `Correction of S<n>.<m>: <reviewer's REJECT line> — fix this; reuse all outputs that passed.` The reviewer prompt template is `templates/CodeStrategy_ReviewerBrief_v1.0.md`.

## 11. Master tasks (rare)

Default: one master task, M1, run by this session. Only when the kickoff answer names more (a very large project, e.g. a marketing follow-on) does the program strategy:
1. Write a program plan holding only shared fixed inputs and the hand-offs between master tasks, plus `.code-strategy/program_state.json` listing each master task's folder and phase.
2. Create one subfolder per master task with its own kickoff file (from the checklist, already answered where the program answers apply), plan, roster, log and `state.json`.
3. Start each master task as its own Claude Code session in its subfolder (`claude --name "<Project> — M2 <name>"`, then `/code-strategy resume`; in the desktop app `start_session` may launch it). Master tasks run in the order their hand-offs require.
4. A master task's merged result is gated by `cs-gate-top` against the program plan before the next master task consumes it. Closeout happens once, at program level.

## 12. Circle-back and closeout (automatic)

At the end of every task, and on any second FAIL: read the task's log entries and the register, verify every logged file exists, then (a) no errors → log a Review entry, continue; (b) errors → corrections per §6. No approval wait.

**Closeout** (last task complete): consolidate `Decisions without input` into one table (decision, where applied, revert cost); list deferred ambiguities from 0.1 and every REJECT with its cause (more context, better prompting, or higher tier); verify every submission file; regenerate the final roster; write the plan PDF if pandoc is available; set `state.phase = done`; print the closeout block; end with `STOP — review closeout before I continue.`

```
CLOSEOUT — <project>
Delivered: <submission files with paths>
Final values: <metric → value, check value, PASS/FAIL>
Gates: <n ACCEPT, m REJECT → causes>
Decisions without input: <table>
Deferred ambiguities: <list | none>
Images pending user: <list | none>
Open items: <list | none>
```

## 13. Portfolio capture

Every subtask exports one working-environment image and one clean output image to the process-images folder, `<Project>_S<n>.<m>_<Desc>_v<M>.<m>.png`; correction runs add the letter. Capture method per tool in the plan's Tooling rules: Rhino `_ViewCaptureToFile` via MCP, 3000 px, named view; Grasshopper Hi-Res Screenshot; SketchUp 2D export at 3000 px; Blender viewport render via MCP; Office documents → PDF → PNG with Python; anything only a screen capture can show → `IMAGE PENDING`, never a stop. Skipped entirely when the kickoff answer is no.

## 14. Plan revisions and roster regeneration

- Structural change (steps, check values, subtasks added, executor changed) → minor version bump, previous file to `_superseded`, index row updated, one-line Revision entry in the log, roster regenerated.
- Status and roster table edits do not bump the version but still regenerate the roster chart.
- Adding a subtask mid-project: insert it in sequence order and the `Depends on` graph; the loop picks it up on the next pass.

## 15. Standing rules

- Never spawn a new instance of a desktop application via MCP; attach to the open session.
- One question per turn. Before the plan: as many turns as there are open questions. After the plan: only at a hard stop, the roster stop, or closeout. `STOP — report <value> before I continue.` is always the last line of such a turn.
- File naming everywhere: `[Subject]_[DocType]_v[Major].[Minor].[ext]`. Store everything in the project folder; the user's stated office formats. Never delete; move superseded versions to `_superseded`.
- Shell: write shell steps as Bash or Python; on Windows the Bash tool runs in Git Bash.
- Nothing under `~/.claude/` is changed by a run (H3).
