# Code Strategy — skill v2.0 for Claude Code

One strategy conversation builds the plan for a project, assigns agents to action it, checks that the plan was followed through review gates, and returns a vetted result. Portable edition: no personal paths, names or format rules.

Contents: `.claude/skills/code-strategy/` (SKILL.md, templates, roster renderer), `.claude/agents/` (9 subagents: 4 executors, intake, review, 3 review gates), `.claude/settings.json` (permission allow/deny list and Stop hook), `.claude/hooks/cs_continue.py`, `.code-strategy/state.json`, `Project_Kickoff_TEMPLATE_v2.0.md`, `CLAUDE_snippet.md`.

Install (Claude Code 2.1 or later):
1. Copy `.claude/skills/code-strategy/` to `~/.claude/skills/` and `.claude/agents/*.md` to `~/.claude/agents/`.
2. Do not edit `~/.claude/settings.json`. The bundle's `.claude/settings.json` (permission allow/deny list, Stop hook) goes into each project folder, because the hook path is relative to the project.
3. In a project folder: copy `.claude/settings.json`, `.claude/hooks/`, `.code-strategy/`, rename the kickoff template to `<Project>_Kickoff_v1.0.md` and fill what you know, append `CLAUDE_snippet.md` to `CLAUDE.md`.
4. Run `claude`, then `/code-strategy <path to brief>`. The session asks every open question one per turn, writes the plan and the roster chart, stops once for roster approval, then runs unattended until closeout.

Model names in the agent files (`sonnet`, `opus`, `fable`) follow the Claude Code aliases current in October 2026; edit the `model:` line if yours differ. License: MIT. Author: Brad Machado, bradmachado.com.
