# Append to the project folder's CLAUDE.md (create the file if absent)

## Code Strategy (skill v2.0)
- This folder is run by the `code-strategy` skill. Start or resume with `/code-strategy`.
- Read `.code-strategy/state.json` first. `hold` → repeat the pending STOP question; `running` → resume at the plan's first non-PASS subtask; `done` → wait for instructions.
- Every clarifying question is asked and answered before any plan or run; the first product is the plan plus the roster chart (`*_Roster_v*.html`).
- Executors read only their packet; every return passes a `cs-gate-*` review before it merges.
- Read Markdown only; source PDFs only when the file index says the Markdown lacks the content.
- File naming: `[Subject]_[DocType]_v[Major].[Minor].[ext]`. Never delete files; move superseded versions to `_superseded`. Nothing under `~/.claude/` changes during a run.
